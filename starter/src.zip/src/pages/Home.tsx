import Navbar from "../components/Navbar/Navbar";
import Hero from "../components/Hero/Hero";
import SearchBar from "../components/SearchBar/SearchBar";
import FilterBar from "../components/FilterBar/FilterBar";

function Home() {
  return (
    <>
      <Navbar />
      <Hero />
      <SearchBar />
      <FilterBar />

      <main>
        {/* Item cards will go here */}
      </main>
    </>
  );
}

export default Home;